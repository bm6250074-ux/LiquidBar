package dev.liquidbar

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

data class Tab(
    val node: AccessibilityNodeInfo,
    val label: String,
    val selected: Boolean,
    val rect: Rect,
)

/**
 * كشف عام للشريط السفلي: عناصر قابلة للنقر في أسفل الشاشة، بحجم متقارب وعلى صف واحد.
 * هذه هي النقطة الأضعف في المشروع (تعتمد على ما يكشفه كل تطبيق في شجرة الإتاحة).
 */
object TabFinder {
    fun find(root: AccessibilityNodeInfo, w: Int, h: Int): List<Tab> {
        val out = mutableListOf<Tab>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 28) return
            if (n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (n.isClickable && r.top >= h * 0.82f && r.width() in 1 until w / 2 &&
                    r.height() in 1 until (h * 0.12f).toInt()
                ) {
                    out += Tab(n, label(n), anySelected(n, 2), r)
                    return
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        val row = out.groupBy { it.rect.top / 24 }.maxByOrNull { it.value.size }?.value ?: return emptyList()
        val sorted = row.sortedBy { it.rect.left }
        return if (sorted.size in 3..6) sorted else emptyList()
    }

    private fun clean(s: CharSequence?) = s?.toString()?.substringBefore(',')?.trim().orEmpty()

    private fun label(n: AccessibilityNodeInfo): String {
        var t = clean(n.contentDescription).ifBlank { clean(n.text) }
        if (t.isBlank()) {
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                t = clean(c.contentDescription).ifBlank { clean(c.text) }
                if (t.isNotBlank()) break
            }
        }
        return t.ifBlank { "•" }.take(14)
    }

    private fun anySelected(n: AccessibilityNodeInfo, depth: Int): Boolean {
        if (n.isSelected) return true
        if (depth == 0) return false
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (anySelected(c, depth - 1)) return true
        }
        return false
    }
}
