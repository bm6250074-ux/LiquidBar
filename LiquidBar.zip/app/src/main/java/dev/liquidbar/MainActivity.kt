package dev.liquidbar

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface { Screen() }
            }
        }
    }
}

private data class Status(val shizuku: Boolean, val perm: Boolean, val secure: Boolean, val enabled: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var st by remember { mutableStateOf(sp.load()) }
    fun update(n: dev.liquidbar.Settings) { st = n; sp.save(n) }

    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }
    val status = remember(tick) {
        Status(ShizukuHelper.running(), ShizukuHelper.granted(), A11y.hasSecure(ctx), A11y.isEnabled(ctx))
    }
    val running by Bus.serviceRunning.collectAsState()
    val lastPkg by Bus.lastPkg.collectAsState()
    val lastTabs by Bus.lastTabs.collectAsState()
    val adb = "adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Liquid Bar", style = MaterialTheme.typography.headlineSmall)

        Box2("الحالة") {
            Line("Shizuku يعمل", status.shizuku)
            Line("صلاحية Shizuku للتطبيق", status.perm)
            Line("صلاحية WRITE_SECURE_SETTINGS", status.secure)
            Line("خدمة الإتاحة مفعّلة", status.enabled)
            Line("الخدمة تعمل الآن", running)
        }

        Box2("التفعيل") {
            Button(onClick = { ShizukuHelper.request() }, enabled = status.shizuku && !status.perm,
                modifier = Modifier.fillMaxWidth()) { Text("1) طلب صلاحية Shizuku") }
            Button(
                onClick = {
                    scope.launch {
                        val r = withContext(Dispatchers.IO) {
                            runCatching {
                                ShizukuHelper.exec("pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS")
                            }.getOrElse { -1 to (it.message ?: "خطأ") }
                        }
                        toast(if (r.first == 0) "تم منح الصلاحية" else "فشل: ${r.second}")
                    }
                },
                enabled = status.perm && !status.secure,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("2) منح WRITE_SECURE_SETTINGS عبر Shizuku") }
            Button(
                onClick = {
                    if (!A11y.setEnabled(ctx, !status.enabled)) toast("تعذّر التعديل، امنح الصلاحية أولاً")
                    tick++
                },
                enabled = status.secure,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (status.enabled) "3) إيقاف الخدمة" else "3) تفعيل الخدمة") }
            OutlinedButton(
                onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("فتح إعدادات الإتاحة يدوياً") }
        }

        Box2("بديل بدون Shizuku (ADB أو أي أداة تنفّذ أوامر shell)") {
            Text(adb, style = MaterialTheme.typography.bodySmall)
            OutlinedButton(
                onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("cmd", adb))
                    toast("تم النسخ")
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("نسخ الأمر") }
        }

        Box2("التطبيقات") {
            SwitchRow("يوتيوب", st.youtube) { update(st.copy(youtube = it)) }
            SwitchRow("واتساب", st.whatsapp) { update(st.copy(whatsapp = it)) }
            SwitchRow("إنستغرام", st.instagram) { update(st.copy(instagram = it)) }
        }

        Box2("المظهر") {
            SliderRow("ارتفاع الكبسولة: ${st.heightDp}dp", st.heightDp.toFloat(), 40f..80f) { update(st.copy(heightDp = it.toInt())) }
            SliderRow("الهامش السفلي: ${st.marginDp}dp", st.marginDp.toFloat(), 0f..56f) { update(st.copy(marginDp = it.toInt())) }
            SliderRow("منطقة الإيماءات السفلية (تُترك حرة): ${st.gestureDp}dp", st.gestureDp.toFloat(), 0f..64f) { update(st.copy(gestureDp = it.toInt())) }
            SliderRow("الشفافية: ${(st.opacity * 100).toInt()}%", st.opacity, 0.3f..1f) { update(st.copy(opacity = it)) }
            SwitchRow("تقلّص عند التمرير", st.shrinkOnScroll) { update(st.copy(shrinkOnScroll = it)) }
            Text("لون الخلفية التي تغطي الشريط الأصلي")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("تلقائي", "داكن", "فاتح").forEachIndexed { i, n ->
                    FilterChip(selected = st.backing == i, onClick = { update(st.copy(backing = i)) }, label = { Text(n) })
                }
            }
        }

        Box2("تشخيص") {
            Text("آخر تطبيق: ${lastPkg.ifBlank { "—" }}")
            Text("التبويبات المكتشفة: ${if (lastTabs.isEmpty()) "—" else lastTabs.joinToString(" | ")}")
        }
    }
}

@Composable
private fun Box2(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun Line(label: String, ok: Boolean) {
    Text((if (ok) "✅ " else "❌ ") + label)
}

@Composable
private fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        Switch(checked = v, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label)
        Slider(value = v, onValueChange = onChange, valueRange = range)
    }
}
