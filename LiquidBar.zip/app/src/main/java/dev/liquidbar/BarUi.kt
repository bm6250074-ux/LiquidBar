package dev.liquidbar

import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BarOverlay(state: State<UiState>, onTab: (Int) -> Unit) {
    val s = state.value
    val st = s.settings
    val dark = when (st.backing) { 1 -> true; 2 -> false; else -> s.dark }
    val backing = if (dark) Color(0xFF0F0F0F) else Color.White
    val pill = (if (dark) Color(0xFF3A3A40) else Color(0xFFE9E9EE)).copy(alpha = st.opacity)
    val fg = if (dark) Color.White else Color(0xFF111111)
    val h by animateDpAsState(
        targetValue = if (s.shrunk) (st.heightDp * 0.72f).dp else st.heightDp.dp,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "pillHeight",
    )
    val shape = RoundedCornerShape(50)

    // الخلفية تغطي الشريط الأصلي، وتمتص اللمسات خارج الكبسولة
    Box(
        Modifier.fillMaxSize().background(backing).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Row(
            Modifier
                .padding(start = 16.dp, end = 16.dp, bottom = st.marginDp.dp)
                .fillMaxWidth()
                .height(h)
                .background(pill, shape)
                .border(
                    1.dp,
                    Brush.verticalGradient(listOf(Color.White.copy(0.55f), Color.White.copy(0.08f))),
                    shape,
                )
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            s.tabs.forEachIndexed { i, t ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(shape)
                        .background(if (t.selected) fg.copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { onTab(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        t.label,
                        color = fg,
                        fontSize = if (s.shrunk) 10.sp else 12.sp,
                        fontWeight = if (t.selected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
