package dev.liquidbar

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.min

@Composable
fun BarOverlay(state: State<UiState>, onTab: (Int) -> Unit) {
    val s = state.value
    val st = s.settings
    val dark = when (st.backing) { 1 -> true; 2 -> false; else -> s.dark }
    val backing = if (dark) Color(0xFF0F0F0F) else Color.White
    val fg = if (dark) Color.White else Color(0xFF111111)
    val glassTop = if (dark) Color(0xFF55555C) else Color(0xFFFFFFFF)
    val glassBottom = if (dark) Color(0xFF2B2B30) else Color(0xFFD9D9E0)
    val shape = RoundedCornerShape(50)
    val n = s.tabs.size.coerceAtLeast(1)
    val sel = s.tabs.indexOfFirst { it.selected }

    val h by animateDpAsState(
        targetValue = if (s.shrunk) (st.heightDp * 0.72f).dp else st.heightDp.dp,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "pillHeight",
    )
    // فقاعة التحديد: تنزلق بنابض وتتمدد أثناء الحركة (إحساس "السائل")
    val pos = remember { Animatable(0f) }
    LaunchedEffect(sel) {
        if (sel >= 0) pos.animateTo(sel.toFloat(), spring(dampingRatio = 0.55f, stiffness = 180f))
    }

    Box(
        Modifier.fillMaxSize().background(backing).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Box(
            Modifier
                .padding(start = 16.dp, end = 16.dp, bottom = st.marginDp.dp)
                .fillMaxWidth()
                .height(h)
                .shadow(14.dp, shape, ambientColor = Color.Black.copy(0.25f), spotColor = Color.Black.copy(0.35f))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(glassTop.copy(alpha = st.opacity), glassBottom.copy(alpha = st.opacity))))
                .border(
                    1.dp,
                    Brush.linearGradient(listOf(Color.White.copy(0.8f), Color.White.copy(0.05f), Color.White.copy(0.35f))),
                    shape,
                ),
        ) {
            // لمعة علوية
            Box(
                Modifier.fillMaxWidth().fillMaxHeight(0.5f)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(0.28f), Color.Transparent))),
            )
            BoxWithConstraints(Modifier.fillMaxSize().padding(4.dp)) {
                val itemW = maxWidth / n
                if (sel >= 0) {
                    val stretch = 1f + 0.45f * min(1f, abs(sel - pos.value))
                    val bubble = if (dark) listOf(Color.White.copy(0.28f), Color.White.copy(0.10f))
                    else listOf(Color.White.copy(0.95f), Color.White.copy(0.65f))
                    Box(
                        Modifier
                            .offset(x = itemW * pos.value - itemW * (stretch - 1f) / 2f)
                            .width(itemW * stretch)
                            .fillMaxHeight()
                            .clip(shape)
                            .background(Brush.verticalGradient(bubble))
                            .border(1.dp, Color.White.copy(0.6f), shape),
                    )
                }
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    s.tabs.forEachIndexed { i, t ->
                        Box(
                            Modifier.weight(1f).fillMaxHeight().clip(shape).clickable { onTab(i) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                t.label,
                                color = fg,
                                fontSize = if (s.shrunk) 10.sp else 12.sp,
                                fontWeight = if (t.selected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}
