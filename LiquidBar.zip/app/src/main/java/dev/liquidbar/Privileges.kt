package dev.liquidbar

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku

object ShizukuHelper {
    fun running() = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun granted() = runCatching {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    fun request() {
        runCatching { Shizuku.requestPermission(1001) }
    }

    /** ينفّذ أمر shell بصلاحية Shizuku. newProcess مخفية في الإصدار 13 فنستدعيها بالانعكاس. */
    fun exec(cmd: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java,
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to (out + err).trim()
    }
}

object A11y {
    private fun component(ctx: Context) = ComponentName(ctx, BarAccessibilityService::class.java)

    fun hasSecure(ctx: Context) =
        ctx.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    fun isEnabled(ctx: Context): Boolean {
        val cur = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val me = component(ctx)
        return cur.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    fun setEnabled(ctx: Context, on: Boolean): Boolean = try {
        val cr = ctx.contentResolver
        val me = component(ctx)
        val list = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            .split(':').filter { it.isNotBlank() && ComponentName.unflattenFromString(it) != me }
            .toMutableList()
        if (on) list.add(me.flattenToString())
        Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":"))
        Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        true
    } catch (e: SecurityException) {
        false
    }
}
