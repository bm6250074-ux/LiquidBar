package dev.liquidbar

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class BarAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private var overlay: ComposeView? = null
    private var owner: OverlayOwner? = null
    private var lp: WindowManager.LayoutParams? = null
    private val ui = mutableStateOf(UiState())
    private var tabs: List<Tab> = emptyList()
    private var pending = false
    private var settings = Settings()

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { p, _ ->
        settings = p.load()
        ui.value = ui.value.copy(settings = settings)
        scheduleScan()
    }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sp = getSharedPreferences("settings", MODE_PRIVATE)
        settings = sp.load()
        ui.value = ui.value.copy(settings = settings)
        sp.registerOnSharedPreferenceChangeListener(prefListener)
        Bus.serviceRunning.value = true
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.packageName == packageName) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (settings.shrinkOnScroll && Build.VERSION.SDK_INT >= 28 && overlay != null) {
                    val dy = e.scrollDeltaY
                    if (dy > 0) setShrunk(true) else if (dy < 0) setShrunk(false)
                }
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                setShrunk(false)
                scheduleScan()
            }
            else -> scheduleScan()
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        hide()
        if (::sp.isInitialized) sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        Bus.serviceRunning.value = false
    }

    private fun setShrunk(v: Boolean) {
        if (ui.value.shrunk != v) ui.value = ui.value.copy(shrunk = v)
    }

    // تحديد وتيرة الفحص حتى لا نمسح الشجرة مع كل حدث
    private fun scheduleScan() {
        if (pending) return
        pending = true
        handler.postDelayed({ pending = false; scan() }, 150)
    }

    private fun scan() {
        try {
            val root = rootInActiveWindow
            val pkg = root?.packageName?.toString()
            val enabled = when (pkg) {
                "com.google.android.youtube" -> settings.youtube
                "com.whatsapp", "com.whatsapp.w4b" -> settings.whatsapp
                "com.instagram.android" -> settings.instagram
                else -> false
            }
            val keyboard = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            if (root == null || !enabled || keyboard) { hide(); return }

            val s = screen()
            val found = TabFinder.find(root, s.width(), s.height())
            Bus.lastPkg.value = pkg.orEmpty()
            Bus.lastTabs.value = found.map { it.label }
            if (found.isEmpty()) { hide(); return }

            tabs = found
            ui.value = ui.value.copy(
                tabs = found.map { TabUi(it.label, it.selected) },
                settings = settings,
                dark = isDark(),
            )
            show(found.minOf { it.rect.top })
        } catch (e: Exception) {
            hide()
        }
    }

    private fun show(barTop: Int) {
        val h = screen().height()
        val height = (h - (barTop - dp(4))).coerceIn(dp(48), h / 3)
        val cur = lp
        if (overlay == null || cur == null) {
            val o = OverlayOwner().also { it.start() }
            val cb: (Int) -> Unit = { onTabClick(it) }
            val v = ComposeView(this).apply {
                setViewTreeLifecycleOwner(o)
                setViewTreeSavedStateRegistryOwner(o)
                setViewTreeViewModelStoreOwner(o)
                setContent { BarOverlay(ui, cb) }
            }
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply { gravity = Gravity.BOTTOM }
            wm.addView(v, p)
            overlay = v; owner = o; lp = p
        } else if (cur.height != height) {
            cur.height = height
            wm.updateViewLayout(overlay, cur)
        }
    }

    private fun hide() {
        overlay?.let { runCatching { wm.removeView(it) } }
        owner?.stop()
        overlay = null; owner = null; lp = null
    }

    private fun onTabClick(i: Int) {
        val t = tabs.getOrNull(i) ?: return
        val ok = t.node.refresh() && t.node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (!ok) tap(t.rect.centerX(), t.rect.centerY())
        handler.postDelayed({ scheduleScan() }, 250)
    }

    // نقرة بالإحداثيات كاحتياط: نجعل النافذة غير قابلة للمس لحظياً كي تصل النقرة للتطبيق
    private fun tap(x: Int, y: Int) {
        val p = lp; val v = overlay
        if (p != null && v != null) {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(v, p)
        }
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(),
            null, null,
        )
        handler.postDelayed({
            val p2 = lp; val v2 = overlay
            if (p2 != null && v2 != null) {
                p2.flags = p2.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                wm.updateViewLayout(v2, p2)
            }
        }, 300)
    }

    private fun screen(): Rect =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds
        else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun isDark() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
}
