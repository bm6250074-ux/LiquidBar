package dev.liquidbar

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

data class Settings(
    val youtube: Boolean = true,
    val whatsapp: Boolean = true,
    val instagram: Boolean = true,
    val heightDp: Int = 56,
    val marginDp: Int = 24,
    val opacity: Float = 0.85f,
    val backing: Int = 0, // 0 تلقائي، 1 داكن، 2 فاتح
    val shrinkOnScroll: Boolean = true,
)

fun SharedPreferences.load() = Settings(
    getBoolean("yt", true), getBoolean("wa", true), getBoolean("ig", true),
    getInt("h", 56), getInt("m", 24), getFloat("o", 0.85f), getInt("b", 0),
    getBoolean("shrink", true),
)

fun SharedPreferences.save(s: Settings) {
    edit()
        .putBoolean("yt", s.youtube).putBoolean("wa", s.whatsapp).putBoolean("ig", s.instagram)
        .putInt("h", s.heightDp).putInt("m", s.marginDp).putFloat("o", s.opacity)
        .putInt("b", s.backing).putBoolean("shrink", s.shrinkOnScroll)
        .apply()
}

data class TabUi(val label: String, val selected: Boolean)

data class UiState(
    val tabs: List<TabUi> = emptyList(),
    val shrunk: Boolean = false,
    val settings: Settings = Settings(),
    val dark: Boolean = true,
)

object Bus {
    val serviceRunning = MutableStateFlow(false)
    val lastPkg = MutableStateFlow("")
    val lastTabs = MutableStateFlow<List<String>>(emptyList())
}
